// 1979 compact single-cab LUV tribute. The wooden caja is built board by board.
export function timberLuv(T,{p,paint,windows,env,box,obj,steel,rubber,rim}) {
 p.name='1979 Chevrolet LUV · caja de madera';paint.color.setHex(0x40af30);paint.metalness=.04;paint.roughness=.32;paint.clearcoatRoughness=.16;paint.envMapIntensity=1.18;
 const newM=(color,roughness=.46,metalness=.1)=>new T.MeshStandardMaterial({color,roughness,metalness});
 const iron=newM(0x39332d,.67,.31),cream=newM(0x928d82,.40,.50),honey=newM(0xde922c,.36,.32);
 const lens=new T.MeshPhysicalMaterial({color:0xe8e5cd,roughness:.19,clearcoat:1,envMap:env,emissive:0x665436,emissiveIntensity:.37});
 const brake=new T.MeshPhysicalMaterial({color:0x8e231d,emissive:0xff361e,emissiveIntensity:.17,clearcoat:1,roughness:.22,envMap:env});
 const B=(m,x,y,z,w,h,d)=>box(m,p,x,y,z,w,h,d);
 // Extruded sheet-metal sections have bevels that pick up highlights along their edges.
 function panel(points,depth,z,m,bevel=.012){let s=new T.Shape();points.forEach(([x,y],i)=>s[i?'lineTo':'moveTo'](x,y));s.closePath();let g=new T.ExtrudeGeometry(s,{depth,bevelEnabled:!!bevel,bevelSegments:3,bevelSize:bevel,bevelThickness:bevel,steps:1});return obj(g,m,p,0,0,z);}
 function cyl(mat,x,y,z,r,l,axis='z',sides=24,par=p){let g=new T.CylinderGeometry(r,r,l,sides);if(axis==='z')g.rotateX(Math.PI/2);if(axis==='x')g.rotateZ(Math.PI/2);return obj(g,mat,par,x,y,z);}
 const woodTextures=[],woodMaterials=[];for(let k=0;k<5;k++){const W=256,H=64,data=new Uint8Array(W*H*4);let seed=k+29;
 for(let y=0;y<H;y++)for(let x=0;x<W;x++){seed=(Math.imul(seed,1664525)+1013904223)>>>0;let grain=y*.8+1.3*Math.sin(x*.023+k)+.62*Math.sin(x*.045+y*.07);let knot=Math.hypot((x-58-26*k)*.105,(y-21-3*k)*.72);let q=.92+.073*Math.sin(grain)+.044*Math.sin(grain*3.4)-.14*Math.exp(-knot*.10)*(1+Math.cos(knot*3))+.065*((seed>>>24)/255-.5);let j=(y*W+x)*4;[165+6*k,100+4*k,52+4*k].forEach((v,i)=>data[j+i]=Math.min(255,v*q));data[j+3]=255;}
 let t=new T.DataTexture(data,W,H);t.colorSpace=T.SRGBColorSpace;t.magFilter=T.LinearFilter;t.minFilter=T.LinearMipmapLinearFilter;t.generateMipmaps=true;t.needsUpdate=true;woodTextures.push(t);woodMaterials.push(new T.MeshStandardMaterial({map:t,roughness:.61,metalness:0}));}
 let n=0;function plank(x,y,z,length,height,width,turn=0){let o=B(woodMaterials[n++%5],x,y,z,length,height,width);o.rotation.y=turn;return o;}
 B(iron,0,.29,0,2.92,.13,.56);
 // The front fender actually clears the wheel; the rear arches are separate from the timber.
 let outline=[[-.23,.30],[.60,.30]];for(let j=0;j<=18;j++){let a=Math.PI-j*Math.PI/18;outline.push([.94+.293*Math.cos(a),.26+.293*Math.sin(a)]);}outline.push([1.46,.30],[1.48,.65],[1.36,.71],[.70,.76],[-.24,.72]);panel(outline,1.11,-.555,paint);
 // A hollow cab allows the windows to reflect the district while showing the bench and steering wheel.
 windows.color.setHex(0x9caeaa);windows.metalness=.04;windows.transparent=true;windows.opacity=.45;windows.depthWrite=false;windows.side=T.FrontSide;
 function bar(mat,a,b,w,d=w){let start=new T.Vector3(...a),end=new T.Vector3(...b),delta=end.clone().sub(start),center=start.clone().lerp(end,.5);let o=B(mat,center.x,center.y,center.z,w,delta.length(),d);o.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),delta.normalize());return o;}
 for(let sign of [-1,1]){let z=sign*.511;
 panel([[-.223,.711],[-.20,1.213],[-.113,1.233],[-.13,.79],[.62,.79],[.71,.747]],.034,z-.017,paint);
 bar(paint,[.694,.761,z],[.382,1.227,z],.051,.05);bar(rubber,[.655,.772,z],[.358,1.206,z],.015,.026);
 const win=[[-.13,.796],[-.117,1.197],[.347,1.197],[.621,.796]];panel(win,.006,z-.003,windows,.002);
 bar(rim,[-.14,.788,z*1.044],[.635,.788,z*1.044],.012);bar(steel,[.468,.794,z],[.383,1.155,z],.011);
 bar(iron,[-.158,.315,sign*.57],[-.158,.711,sign*.57],.009);bar(iron,[-.158,.315,sign*.57],[.455,.315,sign*.57],.008);
 B(honey,1.30,.586,sign*.57,.11,.04,.013);}
 B(paint,-.206,.832,0,.035,.235,1.012);B(paint,-.184,1.197,0,.032,.056,1.01);B(windows,-.218,1.036,0,.014,.26,.90);
 const wind=B(windows,.549,.989,0,.014,.531,.968);wind.rotation.z=.60;
 B(iron,.529,.788,0,.26,.082,.96);B(iron,.05,.755,0,.38,.066,.84);let bench=B(steel,-.094,.846,0,.072,.22,.83);bench.rotation.z=.1;
 const steer=obj(new T.TorusGeometry(.093,.008,7,26),rubber,p,.34,.865,-.25);steer.rotation.y=Math.PI/2-.16;steer.rotation.x=.42;
 for(let z of [-.22,.20]){bar(rubber,[.697,.782,z+.08],[.638,.842,z-.04],.009);bar(rubber,[.655,.825,z-.17],[.630,.851,z+.09],.014);}
 // Crown and two gently pinched hood shoulders, visible as the sky reflection rolls across them.
 {let vs=[],ix=[];const N=16,M=28;for(let i=0;i<=N;i++){const t=i/N,x=.696+.766*t;for(let j=0;j<=M;j++){let u=j/M*2-1,z=u*(.525-.025*t),y=.776-.067*t-.029*t**5+.016*(1-u*u)+.011*Math.exp(-((Math.abs(u)-.64)**2)/.018)-.013*Math.abs(u)**8;vs.push(x,y,z);if(i<N&&j<M){let k=i*(M+1)+j;ix.push(k,k+1,k+M+1,k+1,k+M+2,k+M+1);}}}let g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(vs,3));g.setIndex(ix);g.computeVertexNormals();obj(g,paint,p,0,0,0);}
 panel([[-.22,1.205],[-.16,1.256],[.374,1.253],[.416,1.22]],1.09,-.545,paint,.014);
 for(let s of [-1,1]){B(rim,.06,.731,s*.572,.14,.028,.026);B(steel,.49,.815,s*.59,.032,.038,.15);B(rubber,.51,.85,s*.666,.095,.085,.038);for(let i=0;i<3;i++)B(rubber,-.184,.82+i*.034,s*.528,.063,.012,.01);B(cream,.54,.673,s*.57,.13,.026,.009);}
 B(steel,1.488,.54,0,.032,.205,1.064);for(let k=-2;k<=2;k++)B(rim,1.508,.543+.032*k,0,.019,.011,.70);
 for(let s of [-1,1]){B(rubber,1.51,.553,s*.394,.038,.182,.314);for(const off of [-.077,.077]){cyl(rim,1.534,.553,s*(.394+off),.072,.024,'x');cyl(lens,1.55,.553,s*(.394+off),.062,.018,'x');}B(honey,1.502,.410,s*.40,.022,.044,.108);}
 for(let j=-6;j<=6;j++)B(iron,1.517,.544,j*.046,.009,.145,.009);B(rim,1.496,.333,0,.084,.094,1.18);for(let side of [-1,1]){B(rim,1.429,.333,side*.579,.136,.090,.037);B(iron,1.541,.328,side*.376,.01,.047,.095);}
 // Nine floorboards, raised side rails and a working-truck tailgate with hinge straps.
 for(let j=0;j<9;j++)plank(-.91,.56,(j-4)*.138,1.33,.071,.133);
 for(let j=0;j<4;j++){let y=.659+j*.13;for(let s of [-1,1])plank(-.91,y,s*.609,1.35,.107,.045);plank(-1.553,y,0,1.19,.109,.048,Math.PI/2);plank(-.27,y,0,1.18,.106,.048,Math.PI/2);}
 for(let s of [-1,1]){for(let x of [-1.52,-.88,-.31]){const o=plank(x,.832,s*.637,.61,.054,.050);o.rotation.z=Math.PI/2;B(iron,x,.588,s*.645,.094,.12,.027);for(let y of [.665,.925,1.055])cyl(rim,x,y,s*.67,.013,.012,'z',8);}
 plank(-.915,1.102,s*.618,1.41,.052,.076);B(iron,-1.555,.456,s*.42,.045,.096,.133);B(brake,-1.582,.458,s*.42,.021,.067,.10);B(iron,-1.582,.74,s*.37,.019,.31,.041);cyl(rim,-1.589,.596,s*.37,.024,.115);B(steel,-.96,.455,s*.58,.60,.068,.13);}
 B(iron,-1.526,.325,0,.103,.083,1.20);
 const wheels=[];for(let x of [-.94,.94])for(let sign of [-1,1]){let spindle=new T.Group(),g=new T.Group();p.add(spindle);spindle.position.set(x,.258,sign*.519);spindle.add(g);cyl(rubber,0,0,0,.258,.165,'z',32,g);cyl(cream,0,0,sign*.084,.156,.025,'z',28,g);cyl(rim,0,0,sign*.107,.075,.027,'z',24,g);for(let j=0;j<6;j++){let a=j*Math.PI/3;cyl(iron,.119*Math.cos(a),.119*Math.sin(a),sign*.101,.019,.009,'z',10,g);}wheels.push({x,sign,spindle,g,angle:0});}
 return {p,paint,windows,brake,lens,wheels,last:0,prevV:0,release(){woodTextures.forEach(t=>t.dispose());[...woodMaterials,iron,cream,honey].forEach(m=>m.dispose());}};
}
