// One WASM runtime per page; each exhibit still owns and deletes its model/data.
let loading=null;
export function loadMuJoCo(){
 if(!loading)loading=import('./vendor/mujoco.js').then(({default:load})=>load({locateFile:p=>new URL('./vendor/'+p,import.meta.url).href})).catch(error=>{loading=null;throw error;});
 return loading;
}
