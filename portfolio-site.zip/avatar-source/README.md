# Kenneth character source

The website character and downloadable `kenneth-avatar.glb` are generated from the same geometry in `game.js` and `head-study-model.js`. The face is a connected, shaped surface with dimensional eyes, eyelids, nose, brows, lips and facial hair; no photograph or printed face panel is used.

The model is a stylized miniature for the career world. It is an approximation of Kenneth's likeness, not a scanned portrait. The GLB has a rigid-leg `Walk` animation, not a skeletal motion-capture rig or facial animation system.

## Rebuild

With Node.js 24, run `node avatar-source/export.mjs` from the website directory. An optional first argument selects another website directory. This writes the self-contained GLB beside `game.js`. No package installation or website build step is required.

The avatar studio controls head size, face width, hair volume and body width. The geometry validates settings and exports a neutral default pose.

## Verification

The actual exported GLB was imported into Blender 3.6 and rendered from front, close-up and profile views. Geometry, normals, walk/idle playback, parameter validation, tuning, GLB structure and idempotent resource cleanup were checked. See `validation.json`.
