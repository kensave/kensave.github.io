// Keep labels at their roof anchors. Hide a lower-priority label if it collides,
// rather than moving it across the scene or turning the world into a card grid.
export function visibleNameplates(labels,width,height){
 const visible=new Set(),placed=[],gap=6;
 for(const label of [...labels].sort((a,b)=>b.priority-a.priority||a.depth-b.depth)){
  if(label.depth<=0||label.x<4||label.y<4||label.x+label.width>width-4||label.y+label.height>height-4)continue;
  if(placed.some(b=>label.x<b.x+b.width+gap&&label.x+label.width+gap>b.x&&label.y<b.y+b.height+gap&&label.y+label.height+gap>b.y))continue;
  placed.push(label);visible.add(label.id);
 }
 return visible;
}
