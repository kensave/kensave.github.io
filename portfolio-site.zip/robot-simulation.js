// Floating-base dynamics: locomotion is produced by joint torques and floor contacts.
export {CONTACT_ROBOT_XML as ROBOT_XML,createTorqueBiped as createBiped} from './biped-dynamics.js';
