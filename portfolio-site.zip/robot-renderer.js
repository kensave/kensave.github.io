import * as T from './vendor/three.module.js';
import {createRobotVisual} from './robot-visual.js';
import {readTheme} from './design-system.js';
import {robotCameraPreset} from './robot-camera.js';
export function createRobotRenderer(canvas,sim){
 const context=canvas.getContext('webgl2',{antialias:true,alpha:false});if(!context)return null;
 const theme=readTheme(),renderer=new T.WebGLRenderer({canvas,context,antialias:true});renderer.setPixelRatio(Math.min(devicePixelRatio,1.75));renderer.setClearColor(theme.paper);renderer.outputColorSpace=T.SRGBColorSpace;renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.1;renderer.shadowMap.enabled=true;renderer.shadowMap.type=T.PCFSoftShadowMap;
 const visual=createRobotVisual(sim,theme),camera=new T.PerspectiveCamera(36,1,.1,45),target=new T.Vector3(0,.85,0);let yaw=.82,pitch=.18,distance=4.3,portrait=false,disposed=false;
 const resize=()=>{const w=canvas.clientWidth,h=canvas.clientHeight;renderer.setSize(w,h,false);camera.aspect=w/Math.max(1,h);camera.updateProjectionMatrix();};const observer=new ResizeObserver(resize);observer.observe(canvas);resize();
 return {get yaw(){return yaw;},orbit(dx,dy){yaw-=dx*.007;pitch=T.MathUtils.clamp(pitch+dy*.004,-.05,.65);},zoom(delta){distance=T.MathUtils.clamp(distance+delta*.004,portrait?1.2:3,7);},preset(name){const p=robotCameraPreset(name,sim.heading);portrait=p.portrait;yaw=p.yaw;pitch=p.pitch;distance=p.distance;},resetView(){yaw=.82;pitch=.18;distance=4.3;portrait=false;},draw(){if(disposed)return;visual.sync();const p=sim.position,headY=sim.data.xpos[sim.head*3+2]+.04;target.lerp(new T.Vector3(p.x,portrait?headY:.85,-p.y),.15);camera.position.set(target.x+Math.sin(yaw)*Math.cos(pitch)*distance,target.y+Math.sin(pitch)*distance,target.z+Math.cos(yaw)*Math.cos(pitch)*distance);camera.lookAt(target);renderer.render(visual.scene,camera);},dispose(){if(disposed)return;disposed=true;observer.disconnect();visual.dispose();renderer.dispose();}};
}
