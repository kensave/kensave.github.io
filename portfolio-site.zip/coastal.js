import {blocks} from './district.js';
// Narrow loader for the single, embedded glTF primitive shipped with this exhibit.
export async function loadCoastalHead(T){
 const response=await fetch(new URL('./assets/kenneth-coastal.glb',import.meta.url));if(!response.ok)throw Error('Head unavailable');
 const bytes=await response.arrayBuffer(),dv=new DataView(bytes),len=dv.getUint32(12,true),g=JSON.parse(new TextDecoder().decode(new Uint8Array(bytes,20,len))),start=len+28;
 const geo=new T.BufferGeometry();for(const [i,name,n] of [[0,'position',3],[1,'normal',3],[2,'uv',2],[3,'index',1]]){const a=g.accessors[i],v=g.bufferViews[a.bufferView],arr=new (i===3?Uint16Array:Float32Array)(bytes,start+v.byteOffset,a.count*n),at=new T.BufferAttribute(arr,n);if(i===3)geo.setIndex(at);else geo.setAttribute(name,at);}
 const v=g.bufferViews[g.images[0].bufferView],url=URL.createObjectURL(new Blob([bytes.slice(start+v.byteOffset,start+v.byteOffset+v.byteLength)],{type:'image/jpeg'}));let tex;
 try{tex=await new T.TextureLoader().loadAsync(url);}catch(e){geo.dispose();throw e;}finally{URL.revokeObjectURL(url);}
 tex.flipY=false;tex.colorSpace=T.SRGBColorSpace;const m=new T.Mesh(geo,new T.MeshStandardMaterial({map:tex,roughness:.79}));m.name='Kenneth coastal likeness';m.castShadow=true;return m;
}
export function coastalLandscape(T,scene){
 const unit=new T.BoxGeometry(1,1,1),batches=new Map(),mat=(color,roughness=.76)=>new T.MeshStandardMaterial({color,roughness}),asphalt=mat(0x40434a),sidewalk=mat(0xa9a39b),stripe=mat(0xc8b16a),paint=mat(0xe9e3d8),steel=mat(0x454b50),glass=mat(0x46545f,.26),lamp=new T.MeshBasicMaterial({color:0xffce83}),loft=mat(0xffffff),roof=mat(0x575759),tile=mat(0x817e78);
 if(typeof document!=='undefined'){const t=new T.TextureLoader().load(new URL('./assets/brick-lofts.webp',import.meta.url).href);t.colorSpace=T.SRGBColorSpace;t.anisotropy=4;loft.map=t;const tar=new T.TextureLoader().load('./assets/asphalt-finish.webp');tar.wrapS=tar.wrapT=T.RepeatWrapping;tar.repeat.set(45,45);tar.anisotropy=4;tar.colorSpace=T.SRGBColorSpace;asphalt.color.setHex(0xffffff);asphalt.map=tar;asphalt.bumpMap=tar;asphalt.bumpScale=.009;}
 function box(m,x,y,z,w,h,d){let list=batches.get(m);if(!list)batches.set(m,list=[]);list.push([x,y,z,w,h,d]);}
 box(asphalt,0,-.24,0,140,.32,140);box(sidewalk,0,-.117,0,25.8,.20,25.8);
 // Four street crossings, road markings and cast-concrete curbs.
 for(const sign of [-1,1]){for(let i=-57;i<58;i+=4){if(Math.abs(i)<2||(Math.abs(i)>12&&Math.abs(i)<19))continue;for(const off of [-.075,.075]){box(stripe,i,-.066,sign*16+off,2.5,.02,.052);box(stripe,sign*16+off,-.066,i,.052,.02,2.5);}}
 for(let k=0;k<9;k++){const v=(13.4+k*.65)*sign;box(paint,0,-.058,v,2.8,.028,.26);box(paint,v,-.058,0,.26,.028,2.8);}
 for(let side of [-1,1])for(let k=0;k<8;k++){const lane=side*(13.32+k*.77);box(paint,sign*12.16,-.053,lane,.73,.021,.32);box(paint,lane,-.053,sign*12.16,.32,.021,.73);}
 box(sidewalk,sign*20.05,-.06,0,1.8,.15,39);box(sidewalk,0,-.06,sign*20.05,39,.15,1.8);
 for(let i=-12;i<=12;i+=2){box(tile,i,.005,sign*12.8,1.96,.11,.2);box(tile,sign*12.8,.005,i,.2,.11,1.96);}
 for(let k of [-10,0,10]){let x=k,z=sign*12.4;box(steel,x,1.6,z,.09,3.2,.09);box(steel,x,3.19,z+sign*.4,.10,.09,.9);box(lamp,x,3.14,z+sign*.78,.21,.08,.47);}
 }
 // Keep the foreground sight line open from the playable camera.
 for(let [x,z,w,h,d] of blocks){
 box(sidewalk,x,-.03,z,w+1.2,.18,d+1.4);box(loft,x,h/2+.07,z,w,h,d);box(roof,x,h+.13,z,w+.17,.17,d+.18);box(steel,x+w*.18,h+.57,z,w*.21,.78,1.22);box(steel,x,1.6,z+d/2+.29,w*.89,.11,.70);}
 for(let i=0;i<20;i++){let x=-53+i*5.6,z=-41-(i%3)*3,h=8+((i*17)%20);box(glass,x,h/2,z,4.7,h,6);for(let k=2;k<h;k+=2)box(steel,x,k,z+3,4.7,.12,.09);}
 const dummy=new T.Object3D();for(const [m,items]of batches){const mesh=new T.InstancedMesh(unit,m,items.length);items.forEach(([x,y,z,w,h,d],i)=>{dummy.position.set(x,y,z);dummy.scale.set(w,h,d);dummy.updateMatrix();mesh.setMatrixAt(i,dummy.matrix);});scene.add(mesh);}
}
