// x,z,width,height,depth. Rendering and navigation share the same footprints.
export const blocks=[[-16,-23,10,8,6],[-4,-22,11,6.5,6],[7,-23,8,8,6],[18,-24,10,5.9,7],[-23,-12,6,7,11],[-23,1,6,6.7,10],[-23,13,7,7.8,11],[25,-12,7,4.2,8],[-12,25,9,4,7]];
export const extent=28;
export function outsideBuildings(x,z){return blocks.every(([cx,cz,w,,d])=>Math.abs(x-cx)>=w/2+.32||Math.abs(z-cz)>=d/2+.32);}
export function streetClamp(x,z){x=Math.max(-extent,Math.min(extent,x));z=Math.max(-extent,Math.min(extent,z));for(let [cx,cz,w,,d] of blocks){let dx=x-cx,dz=z-cz,a=w/2+.32-Math.abs(dx),b=d/2+.32-Math.abs(dz);if(a>0&&b>0){if(a<b)x+=a*Math.sign(dx||1);else z+=b*Math.sign(dz||1);}}return{x,z};}

export function footLevel(x,z){let r=Math.max(Math.abs(x),Math.abs(z));if(r<12.7)return .01;if(r<13.1)return .01-(r-12.7)*.225;if(r>=19.15&&r<=20.95)return .015;return -.08;}
