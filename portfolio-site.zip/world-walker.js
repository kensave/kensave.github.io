// Responsive game locomotion. This animation controller is intentionally separate
// from the unsupported torque-driven biped in the MuJoCo playground.
import {CONTACT_ROBOT_XML,CONTACT_JOINTS} from './biped-dynamics.js';
import {createIdleSchedule,seededRandom} from './robot-personality.js';
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const angleDelta=(to,from)=>Math.atan2(Math.sin(to-from),Math.cos(to-from));
const ease=u=>u*u*(3-2*u);
export function createWorldWalker(m,{constrain=(x,y)=>({x,y}),speed=1.8,seed=1}={}){
 const model=m.MjModel.from_xml_string(CONTACT_ROBOT_XML),data=new m.MjData(model);
 const id=(type,name)=>m.mj_name2id(model,m.mjtObj[type].value,name),joints={};
 for(const name of CONTACT_JOINTS){const j=id('mjOBJ_JOINT',name);joints[name]={q:model.jnt_qposadr[j]};}
 const personality=createIdleSchedule(seed),random=seededRandom(seed),stride=.75;
 let x=0,y=0,yaw=0,vx=0,vy=0,time=0,phase=0,blend=0,idle=true,disposed=false,input={x:0,y:0},waveUntil=0,attention=null,gesture='Curious & ready',lastCycle=-1,toe=0,lift=.085;
 const valid=()=>{if(disposed)throw Error('Walker disposed');};
 const put=(name,value)=>{const j=joints[name];data.qpos[j.q]=value;};
 // Positions are generated from a two-segment leg; the stance phase cancels
 // forward root travel so a planted foot does not skate along a straight path.
 function pose(){
  data.qpos.fill(0);data.qpos[0]=x;data.qpos[1]=y;data.qpos[2]=.7032+(.66-.7032)*blend+.006*blend*Math.sin(phase*4*Math.PI)**2;
  data.qpos[3]=Math.cos(yaw/2);data.qpos[6]=Math.sin(yaw/2);
  put('spine',idle?.005*Math.sin(time*1.7):0);put('neck_pitch',idle?.025*Math.sin(time*.8):0);
  let gaze=idle&&!blend?.15*Math.sin(time*.4):0;
  if(attention)gaze=clamp(angleDelta(Math.atan2(attention.y-y,attention.x-x),yaw),-.6,.6);
  put('neck_yaw',gaze);
  for(const [i,side]of ['right','left'].entries()){
   const u=(phase+i*.5)%1,swing=u>=.6,w=swing?(u-.6)/.4:0;
   const targetX=stride*(swing?-.3+.6*ease(w):.3-u)*blend;
   const targetZ=.11+(swing?lift*Math.sin(Math.PI*w)**2:0)*blend;
   const height=data.qpos[2]-.02-targetZ,r=Math.min(.599,Math.hypot(targetX,height));
   const knee=Math.acos(clamp((r*r-.18)/.18,-1,1));
   const hip=Math.atan2(-targetX,height)-knee/2;
   put(side+'_hip',hip);put(side+'_knee',knee);put(side+'_ankle',-hip-knee);
   put(side+'_hip_yaw',toe*blend*(side==='right'?1:-1));
   put(side+'_shoulder_pitch',-.06+.28*blend*Math.sin(phase*2*Math.PI+i*Math.PI));
   put(side+'_shoulder_roll',side==='left'?.08:-.08);put(side+'_elbow',-.3);
  }
  const g=personality.sample(time),weight=idle?(1-blend)*g.weight:0;
  gesture=weight>.15?g.name:'Curious & ready';
  const mix=(name,value)=>put(name,data.qpos[joints[name].q]+(value-data.qpos[joints[name].q])*weight);
  if(weight>0){const p=g.phase;if(g.slot===0)mix('neck_yaw',.4*Math.sin(p*1.5));if(g.slot===1)mix('neck_pitch',.13*Math.sin(p*3));if(g.slot===2){mix('left_shoulder_roll',.75);mix('right_shoulder_roll',-.75);}if(g.slot===3){mix('left_shoulder_pitch',-.9);mix('left_elbow',-1.2);mix('neck_pitch',.12);}if(g.slot===4){mix('right_shoulder_pitch',-.7);mix('right_elbow',-1.3);mix('left_shoulder_pitch',-.5);mix('left_elbow',-1.1);}if(g.slot===5)mix('neck_pitch',-.1);if(g.slot===6){mix('right_shoulder_roll',-1.6);mix('right_elbow',-1+.2*Math.sin(p*7));}}
  if(time<waveUntil){put('right_shoulder_roll',-1.6);put('right_elbow',-1+.2*Math.sin(time*7));}
  data.time=time;m.mj_forward(model,data);
 }
 function reset(px=0,py=0,angle=0){valid();if(![px,py,angle].every(Number.isFinite))throw Error('Invalid position');const safe=constrain(px,py);x=safe.x;y=safe.y;yaw=angle;vx=vy=time=phase=blend=waveUntil=0;input={x:0,y:0};lastCycle=-1;personality.reset();random.reset();m.mj_resetData(model,data);pose();}
 function tick(dt){const length=Math.min(1,Math.hypot(input.x,input.y)),targetX=input.x*speed,targetY=input.y*speed,dvx=targetX-vx,dvy=targetY-vy,dv=Math.hypot(dvx,dvy),rate=length>.01?9:13,amount=Math.min(1,rate*dt/Math.max(dv,1e-9));vx+=dvx*amount;vy+=dvy*amount;
  const safe=constrain(x+vx*dt,y+vy*dt),dx=safe.x-x,dy=safe.y-y,distance=Math.hypot(dx,dy);x=safe.x;y=safe.y;
  if(length>.01){const wanted=Math.atan2(input.y,input.x);yaw+=clamp(angleDelta(wanted,yaw),-10*dt,10*dt);}
  const actualSpeed=dt?distance/dt:0,targetBlend=clamp(actualSpeed/.6,0,1);blend+=(targetBlend-blend)*(1-Math.exp(-18*dt));if(blend<.001)blend=0;
  phase+=distance/stride;const cycle=Math.floor(phase);if(cycle!==lastCycle){toe=(random()-.5)*.025;lift=.08+random()*.012;lastCycle=cycle;}time+=dt;pose();
 }
 reset();
 return {model,data,joints,pelvis:id('mjOBJ_BODY','pelvis'),torso:id('mjOBJ_BODY','torso'),head:id('mjOBJ_BODY','head'),hoodie:id('mjOBJ_GEOM','hoodie'),locomotion:'game-animation',get position(){return{x,y,z:data.qpos[2]};},get heading(){return yaw;},get time(){return time;},get gaitPhase(){return phase*2*Math.PI;},get idle(){return idle;},get mode(){return blend>.1?'Walking':gesture;},get idleGesture(){return gesture;},setIdle(value){valid();idle=!!value;},setInput(dx,dy){valid();if(![dx,dy].every(Number.isFinite))throw Error('Invalid movement');const length=Math.max(1,Math.hypot(dx,dy));input={x:dx/length,y:dy/length};},lookAt(point){valid();attention=point;},wave(){valid();waveUntil=time+2.5;},step(dt){valid();if(!Number.isFinite(dt)||dt<0)throw Error('Invalid time step');let remaining=Math.min(dt,.1);while(remaining>1e-9){const h=Math.min(remaining,1/120);tick(h);remaining-=h;}},teleport:reset,reset(){reset();},dispose(){if(disposed)return;disposed=true;data.delete();model.delete();}};
}
