# Kenneth Sánchez — Engineering portfolio

Professional portfolio, résumé, playable career world and experimental MuJoCo biped lab. Static HTML, CSS and JavaScript; no build step. Published with GitHub Pages at https://kensave.github.io/.

Career-world movement uses responsive game animation. The real torque-driven biped controller is a separate, explicitly experimental playground.

Dependencies and reference motion are vendored with their licenses. See vendor/ and vendor/reference/README.md.
