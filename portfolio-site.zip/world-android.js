import {footLevel} from './district.js';
import {loadMuJoCo} from './mujoco-engine.js';
import {createWorldWalker} from './world-walker.js';
import {createRobotVisual} from './robot-visual.js';
import {clampPosition} from './game.js';
export function worldDirectionToRobot(dx,dz){return {x:dx,y:-dz};}
export function worldYawToRobot(yaw){return yaw-Math.PI/2;}
export async function createWorldAndroid(T,scene,{obstacles,theme,reduced=false,engine=null}={}){
 const m=engine||await loadMuJoCo();
 const sim=createWorldWalker(m,{speed:1.8,constrain(x,y){const p=clampPosition(x,-y,obstacles,2.6);return{x:p.x,y:-p.z};}});sim.setIdle(!reduced);
 let visual;try{visual=createRobotVisual(sim,theme);}catch(e){sim.dispose();throw e;}const object=new T.Object3D();visual.root.position.y=.05;scene.add(visual.root);
 const shadowMaterial=new T.MeshBasicMaterial({color:theme.green,transparent:true,opacity:.16,depthWrite:false}),shadow=new T.Mesh(new T.CircleGeometry(.38,32),shadowMaterial);shadow.rotation.x=-Math.PI/2;shadow.scale.y=.65;shadow.position.y=.056;scene.add(shadow);let disposed=false;
 function sync(){const p=sim.position;const floor=footLevel(p.x,-p.y);visual.root.position.y=.04+floor;shadow.position.y=floor+.006;object.position.set(p.x,.04+floor,-p.y);object.rotation.y=sim.heading+Math.PI/2;shadow.position.x=p.x;shadow.position.z=-p.y;visual.sync();}
 const api={object,sim,setVisible(v){visual.root.visible=v;shadow.visible=v;},teleport(x,z,yaw=.65){sim.teleport(x,-z,worldYawToRobot(yaw));sync();},drive(dx,dz,dt){const d=worldDirectionToRobot(dx,dz);sim.setInput(d.x,d.y);sim.step(dt);sync();},lookAt(point){sim.lookAt(point?{x:point.x,y:-point.z}:null);},wave(){sim.wave();},dispose(){if(disposed)return;disposed=true;visual.root.removeFromParent();visual.dispose();shadow.geometry.dispose();shadowMaterial.dispose();shadow.removeFromParent();sim.dispose();}};api.teleport(0,3,.65);return api;
}
