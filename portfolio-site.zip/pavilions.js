export function buildPavilion(T,id,group,box,mesh,materials,signMaterials,signTextures,logoSign,wordSign){
 const specs={agents:['Kiro CLI',3.45,2.68,0x273536,0x96dabe,'kiro.svg'],cloud:['Alexa Shopping',3.32,2.43,0x735540,0xffbd77,'aws.png'],tools:['Microsoft Edge',3.40,2.43,0xbab8aa,0x81c5e9,'microsoft.svg'],seller:['Seller Services',3.55,2.16,0x485259,0xe9b574,'aws.png'],mobilize:['Mobilize.Net',3.1,2.4,0x875743,0xe9bd83,null],lab:['Dynamics Lab',3.46,2.5,0x53606a,0xf0bf71,null]};
 const [name,w,h,tint,accent,logo]=specs[id],d=2.04;
 const trim=new T.MeshStandardMaterial({color:tint,roughness:.63,metalness:.23}),glow=new T.MeshBasicMaterial({color:accent});signMaterials.push(trim,glow);
 const t=new T.TextureLoader().load(new URL('./assets/stand-'+id+'.webp',import.meta.url).href);t.colorSpace=T.SRGBColorSpace;t.anisotropy=4;signTextures.push(t);let front=new T.MeshStandardMaterial({map:t,roughness:.61});signMaterials.push(front);
 const body=box(0,h/2+.14,0,w,h,d,trim,group);mesh(new T.PlaneGeometry(w-.11,h-.10),front,0,h/2+.14,d/2+.013,group);
 for(let sign of [-1,1]){const side=mesh(new T.PlaneGeometry(d-.16,h*.63),front,sign*(w/2+.009),h*.45,0,group);side.rotation.y=sign*Math.PI/2;box(sign*(w/2-.035),h*.51+.12,d/2+.07,.075,h,.15,trim,group);}
 box(0,.07,.16,w+.27,.14,d+.48,materials.path,group);
 box(0,.105,1.31,w*.76,.08,.40,materials.path,group);
 const hood=id==='cloud'?.63:id==='seller'?.55:.37;
 box(0,h+.16,.035,w+.19,.13,d+.20,trim,group);
 box(0,h*.75+.14,1+hood/2,w+.084,.095,hood,trim,group);
 box(0,h*.75+.095,1+hood-.015,w*.94,.027,.027,glow,group);
 // Each chapter has a distinct roof silhouette.
 if(id==='agents'||id==='seller')for(let i=0;i<6;i++)box((i-2.5)*.43,h+.27,-.20,.10,.18,1.28,trim,group);
 if(id==='cloud'){mesh(new T.CylinderGeometry(.58,.72,.23,36),trim,0,h+.34,-.12,group);}
 if(id==='tools')box(-.35,h+.31,-.26,2.25,.25,.88,materials.glass,group);
 if(id==='mobilize')for(let x of [-1.42,1.42])box(x,h+.32,-.55,.21,.49,.24,trim,group);
 if(id==='lab')for(let x of [-1.18,1.18]){let bar=box(x,h+.32,-.11,.09,.40,1.8,trim,group);bar.rotation.x=.08;}
 const sg=wordSign(name,logo?.26:0,h*.885+.13,1.061,logo?w*.66:w*.8,.36,group);
 if(logo)logoSign('./brands/'+logo,-w*.342,h*.885+.13,1.07,.37,.30,group);
 return body;
}
