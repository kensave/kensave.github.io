export const IDLE_GESTURES=['Looking around','A small nod','A little stretch','Checking my hand','Straightening my cuffs','Ready to go','Hello there'];
export function idleGesture(time){
 const duration=5.8,active=4.8,slot=Math.floor(Math.max(0,time)/duration)%IDLE_GESTURES.length,phase=Math.max(0,time)%duration;
 return {slot,name:IDLE_GESTURES[slot],phase,weight:phase<active?Math.sin(Math.PI*phase/active)**2:0};
}

export function seededRandom(seed=1){const initial=(Number(seed)>>>0)||1;let state=initial;const random=()=>{state=(state+0x6d2b79f5)>>>0;let t=state;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return((t^(t>>>14))>>>0)/4294967296;};random.reset=()=>{state=initial;};return random;}
export function createIdleSchedule(seed=1){const random=seededRandom(seed);let bag=[],entries=[],end=0,previous=-1;
 function next(){if(!bag.length){bag=IDLE_GESTURES.map((_,i)=>i);for(let i=bag.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[bag[i],bag[j]]=[bag[j],bag[i]];}if(bag[0]===previous)[bag[0],bag[1]]=[bag[1],bag[0]];}const slot=bag.shift(),active=4.4+random()*.9,pause=.9+random()*.9,entry={slot,start:end,active,end:end+active+pause,amplitude:.75+random()*.25};end=entry.end;previous=slot;entries.push(entry);return entry;}
 return {sample(time){time=Math.max(0,time);while(!entries.length||end<=time)next();const e=entries.find(e=>time<e.end),local=time-e.start,u=local/e.active;return{slot:e.slot,name:IDLE_GESTURES[e.slot],phase:Math.min(4.8,u*4.8),weight:u<1?Math.sin(Math.PI*u)**2*e.amplitude:0};},reset(){random.reset();bag=[];entries=[];end=0;previous=-1;}};
}
