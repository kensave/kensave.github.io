// Public-site statistics only. Private previews and local development stay quiet.
export const analyticsEndpoint='https://kensave.goatcounter.com/count';
export function installAnalytics(doc,loc){
 if(loc.hostname!=='kensave.github.io'||doc.querySelector('script[data-goatcounter]'))return null;
 const script=doc.createElement('script');script.async=true;script.src='https://gc.zgo.at/count.js';
 script.setAttribute('data-goatcounter',analyticsEndpoint);
 const path=loc.pathname==='/index.html'?'/':loc.pathname;
 script.setAttribute('data-goatcounter-settings',JSON.stringify({path}));
 doc.head.append(script);return script;
}
if(typeof document!=='undefined')installAnalytics(document,location);
