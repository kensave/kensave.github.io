from pathlib import Path
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,KeepTogether
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.colors import HexColor
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
root=Path(__file__).resolve().parents[1]
fontroot=Path('/usr/share/fonts/truetype/dejavu')
for name,file in [('Body','DejaVuSans.ttf'),('Bold','DejaVuSans-Bold.ttf'),('Serif','DejaVuSerif.ttf')]:pdfmetrics.registerFont(TTFont(name,str(fontroot/file)))
ink=HexColor('#22332f');muted=HexColor('#647065');green=HexColor('#355947')
styles={
'name':ParagraphStyle('Name',fontName='Serif',fontSize=29,leading=34,textColor=ink,spaceAfter=10),
'role':ParagraphStyle('Role',fontName='Bold',fontSize=9,leading=14,textColor=ink),
'contact':ParagraphStyle('Contact',fontName='Body',fontSize=7.7,leading=12,textColor=muted),
'summary':ParagraphStyle('Summary',fontName='Body',fontSize=8.8,leading=13.5,textColor=ink,spaceBefore=13,spaceAfter=15),
'heading':ParagraphStyle('Heading',fontName='Bold',fontSize=7.5,leading=11,textColor=green,spaceBefore=0,spaceAfter=12),
'job':ParagraphStyle('Job',fontName='Bold',fontSize=9.2,leading=13,textColor=ink,spaceAfter=2),
'date':ParagraphStyle('Date',fontName='Body',fontSize=7.7,leading=11,textColor=muted,spaceAfter=7),
'body':ParagraphStyle('Body',fontName='Body',fontSize=8.6,leading=12.8,textColor=ink,spaceAfter=6),
'bullet':ParagraphStyle('Bullet',fontName='Body',fontSize=8.6,leading=12.8,textColor=ink,leftIndent=9,firstLineIndent=-9,spaceAfter=5),
'side':ParagraphStyle('Side',fontName='Body',fontSize=8.1,leading=12.5,textColor=ink,spaceAfter=12),
}
def P(text,style='body'):return Paragraph(text,styles[style])
def link(url,label):return f'<link href="{url}" color="#355947">{label}</link>'
main=[P('EXPERIENCE','heading')]
def job(name,role,date,bullets):
 content=[P(name,'job'),P(role+'<br/>'+date,'date')]+[P('•  '+b,'bullet') for b in bullets]+[Spacer(1,8)]
 main.extend(content)
job('Amazon Web Services · Kiro CLI','Senior Software Engineer · Previously SDE II','September 2023 - present · Senior since July 2026',[
'Created Twinki, a flicker-free terminal renderer with native full-screen mode, and integrated Kiro Workflows into Kiro.',
'Built /goal, sub-agent monitoring, /knowledge, and Code Intelligence.',
'Built local semantic search and persistent indexing. Integrated language servers for symbols, definitions, references, and diagnostics, alongside AST manipulation.',
'Improved CLI startup, rendering performance, memory use, and distribution size.',
'Built serverless subscription workflows, usage APIs, metering, and activation signals.',
'Co-inventor of '+link('https://patents.justia.com/patent/12764034','U.S. Patent 12,764,034')+' for secure multi-model hosting and experimentation; granted October 13, 2026.'])
job('Amazon · Alexa Shopping','Software Development Engineer II','August 2022 - September 2023',[])
job('Microsoft · Edge Browser','Software Engineer II','December 2021 - August 2022',['Reduced enterprise search result load time from approximately one minute to three seconds.'])
job('Amazon · Seller Services','Software Development Engineer II','February 2019 - December 2021',['Built scalable seller systems and serverless micro-frontends using AWS Lambda and CloudFront.'])
job('Mobilize.Net','Senior Software Engineer','April 2012 - February 2019',['Built automated code analysis and migration tools. Led desktop-to-web modernization involving VB6 and C# WinForms applications.'])
side=[P('ENGINEERING FOCUS','heading'),P('<b>Languages</b><br/>Rust, TypeScript / TSX, JavaScript, C#, C++, Java','side'),P('<b>Agent &amp; developer tools</b><br/>MCP, language servers, AST manipulation, semantic search, retrieval, indexing, agent orchestration, terminal rendering','side'),P('<b>Cloud &amp; systems</b><br/>AWS Lambda, CloudFront, ECS, distributed systems, serverless workflows, APIs, metering, experimentation','side'),P('<b>Interfaces</b><br/>React, terminal interfaces, developer experience','side'),Spacer(1,11),P('OPEN SOURCE','heading'),P('<b>'+link('https://github.com/kensave/roberto-mcp','RobertoMCP')+'</b><br/>Language-agnostic code analysis MCP server.','side'),P('<b>'+link('https://github.com/kensave/agent-memory-rs','agent-memory-rs')+'</b><br/>Agent memory in Rust.','side'),P('<b>'+link('https://github.com/kensave/LanguageSyntaxCreator','LanguageSyntaxCreator')+'</b><br/>Pattern matching and JSON grammar parsing.','side'),Spacer(1,11),P('EDUCATION','heading'),P('<b>Universidad de Costa Rica</b><br/>Computer Engineering<br/>2008 - 2011','side'),Spacer(1,11),P('GRANTED U.S. PATENT','heading'),P(link('https://patents.justia.com/patent/12764034','U.S. Patent 12,764,034')+'<br/>Co-inventor<br/>Granted October 13, 2026','side')]
# Register regular/bold families so inline bold preserves the embedded font.
pdfmetrics.registerFontFamily('Body',normal='Body',bold='Bold',italic='Body',boldItalic='Bold')
story=[P('Kenneth Sánchez','name'),P('Senior Software Engineer · Kiro CLI, Amazon Web Services','role'),P('Bellevue, Washington  |  '+link('mailto:kensave@hotmail.com','kensave@hotmail.com')+'  |  '+link('https://github.com/kensave','GitHub')+'  |  '+link('https://www.linkedin.com/in/kenneth-sanchez-0b894b42','LinkedIn'),'contact'),P('Software engineer with 14+ years of experience at Amazon, Microsoft, and Mobilize.Net. I build developer tools and the systems that help coding agents understand code, retrieve knowledge, and interact with developers. My work spans terminal rendering, semantic search, experimentation, and serverless infrastructure.','summary')]
width=A4[0]-94
layout=Table([[main,side]],colWidths=[width*.66,width*.34],hAlign='LEFT');layout.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),0),('RIGHTPADDING',(0,0),(0,0),25),('RIGHTPADDING',(1,0),(1,0),0),('TOPPADDING',(0,0),(-1,-1),0),('BOTTOMPADDING',(0,0),(-1,-1),0)]));story.append(layout)
def footer(c,doc):
 c.setStrokeColor(HexColor('#d9ddd3'));c.line(41,34,A4[0]-41,34);c.setFillColor(muted);c.setFont('Body',7);c.drawString(41,23,'Kenneth Sánchez · Senior Software Engineer');c.drawRightString(A4[0]-41,23,'kensave.github.io')
doc=SimpleDocTemplate(str(root/'assets/kenneth-sanchez-resume.pdf'),pagesize=A4,rightMargin=41,leftMargin=41,topMargin=37,bottomMargin=42,title='Kenneth Sánchez - Résumé',author='Kenneth Sánchez',pageCompression=1)
doc.build(story,onFirstPage=footer,onLaterPages=footer)
print('Created selectable-text résumé PDF.')
