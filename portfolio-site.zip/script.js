const output = document.getElementById('terminal-output');
const input = document.getElementById('terminal-input');
const responses = {
  help: 'Commands: about, experience, skills, projects, contact, cv, clear',
  about: 'Kenneth Sanchez\nSenior Software Engineer at AWS · Kiro CLI\nAgent infrastructure, distributed systems, and developer tools\nBellevue, Washington',
  experience: 'AWS · Kiro CLI / Amazon Q Developer CLI · Sep 2023–present\nSenior Software Engineer since July 2026; previously SDE II\nAmazon · Alexa Shopping · Aug 2022–Sep 2023\nMicrosoft · Edge Browser · Dec 2021–Aug 2022\nAmazon · Seller Services · Feb 2019–Dec 2021\nMobilize.Net · Apr 2012–Feb 2019',
  skills: 'Rust, TypeScript / TSX, JavaScript, C#, C++, Java\nAWS Lambda, CloudFront, ECS, serverless workflows\nMCP, language servers, semantic search, indexing\nAgent orchestration, React, terminal rendering',
  projects: 'Kiro CLI: /goal, sub-agent monitoring, /knowledge, Code Intelligence, full-screen mode, terminal renderer\nSubscription platform: serverless workflows, usage APIs, metering, activation signals\nAI experimentation: A/B-testing framework without shared node state\nOpen source: RobertoMCP and LanguageSyntaxCreator',
  contact: 'kensave@hotmail.com\nhttps://www.linkedin.com/in/kenneth-sanchez-0b894b42\nhttps://github.com/kensave',
  cv: 'Use the View / print CV link above, or open cv.html. Choose Print / Save PDF on the CV page.'
};
function append(text) {
  const line = document.createElement('div');
  line.className = 'terminal-line';
  line.textContent = text;
  output.appendChild(line);
  document.getElementById('terminal').scrollTop = document.getElementById('terminal').scrollHeight;
}
input.addEventListener('keydown', event => {
  if (event.key !== 'Enter' || !input.value.trim()) return;
  const command = input.value.trim();
  input.value = '';
  if (command.toLowerCase() === 'clear') { output.replaceChildren(); return; }
  append('$ ' + command);
  append(responses[command.toLowerCase()] || 'Type help to explore my experience, skills, and projects.');
});
append("Kenneth's portfolio terminal\nType help to explore.\n");

