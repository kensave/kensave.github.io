export function robotCameraPreset(name,heading=0){
 const front=Math.PI/2+heading,portrait=name==='face';
 return {portrait,yaw:{front,side:front+Math.PI/2,back:front+Math.PI,'three-quarter':front-.75,face:front-.15}[name]??front-.75,pitch:portrait?.04:.18,distance:portrait?1.65:4.3};
}
